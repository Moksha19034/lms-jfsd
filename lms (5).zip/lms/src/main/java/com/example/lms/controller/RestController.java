package com.example.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.lms.dao.UserRepository;
import com.example.lms.entities.User;

@Controller
public class RestController {

    @Autowired
    private UserRepository userRepository;

    @RequestMapping("/home")
    public String home() {
        return "home";
    }

    @RequestMapping("/login")
    public String login() {
        return "login";
    }

    @RequestMapping("/about")
    public String about() {
        return "about";
    }

    @RequestMapping("/registration")
    public String registration() {
        return "registration";
    }

    @RequestMapping("/contact")
    public String contact() {
        return "contact";
    }

    @RequestMapping("/feedback")
    public String feedback() {
        return "feedback";
    }

    @PostMapping("/process")
    public String register(@RequestParam("username") String username,
                           @RequestParam("email") String email,
                           @RequestParam("password") String password) {
        User user = new User(username, password, email);
        userRepository.save(user);
        return "login";  // Redirect to login page after registration
    }

    @PostMapping("/loginUser")
    public String loginUser(@RequestParam("username") String username,
                            @RequestParam("password") String password,
                            Model model) {
        User user = userRepository.findByUsernameAndPassword(username, password);
        if (user != null) {
            return "home";  // Redirect to home page on successful login
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";  // Reload login page with an error message
        }
    }
}
